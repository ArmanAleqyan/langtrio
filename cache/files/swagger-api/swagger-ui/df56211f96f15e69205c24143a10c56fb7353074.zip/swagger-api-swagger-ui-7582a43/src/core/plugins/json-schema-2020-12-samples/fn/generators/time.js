/**
 * @prettier
 */
const timeGenerator = () => new Date().toISOString().substring(11)

export default timeGenerator
